import App from './src/javascript/app';
import './src/styles/styles.css';

App.startApp();
