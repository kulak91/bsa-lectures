export function showWinnerModal(fighter) {
  // call showModal function 
}
