**DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT**

------
### DONALD TRUMP
* https://www.fb.com/DonaldTrump
* realDonaldTrump@whitehouse.gov
* https://twitter.com/realDonaldTrump
* https://www.instagram.com/realDonaldTrump/

------

### ― I'm the most successful person ever to run for the presidency, by far. Nobody's ever been more successful than me. I'm the most successful person ever to run. Ross Perot isn't successful like me. Romney ― I have a Gucci store that's worth more than Romney. Sorry losers and haters, but my IQ is one of the highest ― and you all know it! Please don't feel so stupid or insecure, it's not your fault.

------

#### EXPERIENCE

<small>2017</small>  
Became 45th president of the United States 

<small>2016</small>  
Won election race with 77 votes more than Clinton, yippe-kee-yay!

<small>2015</small>  
Became the most important Republican nominating for presidential election run

<small>2009</small>  
Changed my mind and became Republican again

<small>2005</small>  
Started Trump University with Michael Sexton and Jonathan Spitalny: no grades, certificates  and other bureaucracy, but program offered courses in real estate, asset management entrepreneurship, and wealth creation. 98% students gave positive reviews while studying, however some of these ungrateful gringos filed lawsuits against Trump University after the course. I had to pay $25 million to settle that...

<small>2002</small>  
Acquired the former Hotel Delmonico, which was renovated and reopened in 2004 as the Trump Park Avenue. I sure do like my surname!

<small>2001</small>  
Completed Trump World Tower and joined the Democratic Party 

<small>1999</small>  
Started buying golf courses. They are very cheap, I have 18 of them now in USA and abroad! Also switched to the Reform Party that year

<small>1997</small>  
Began a multi-building development along the Hudson River, which was named Trump Place. Me and the other investors sold our shares for $1.8 billion and that was then the biggest residential sale in the history of New York City

<small>1996</small>  
Acquired the Bank of Manhattan Trust Building, which was a vacant seventy-one story skyscraper on Wall Street. After an extensive renovation, the high-rise was renamed the Trump Building 

<small>1994</small>  
Refurbished the Gulf and Western Building on Columbus Circle, turned it into a 44-story luxury property known as Trump International Hotel and Tower

<small>1989 ― 1992</small>  
Ran a second hand airline called Trump Shuttle. What a waste of money, I had to sell it, now it is American Airlines Shuttle, btw 

<small>1989, 1990</small>  
Learned about Tour de France and decided to hold my very own Tour de Trump. Is America not great enough for that cycling competition? 

<small>1988</small>  
Acquired the Plaza Hotel in Manhattan for $407 million, invested $50 million to restore the building and boosted it  from three-star to four-star hotel (I called it "the Mona Lisa" and sold it for a lot of cash in 1995)

<small>1987</small>  
Registered as a Republican

<small>1985</small>  
I bought the Mar-a-Lago estate in Palm Beach and turned it into a private club.You can join if you pay $200K initiation fee (and there is another annual fee for members, it is very expensive to be rich). That year I also opened a casino called Trump Castle. My wife Ivana became a manager, because she is another Trump!

<small>1983</small>  
I purchased New Jersey Generals, an American football team. I changed team's play schedule and filed an antitrust lawsuit against United States Football League, so NJG are not doing so good now, but back then they were great! 

<small>1980</small>  
Started developing the Trump Tower skyscraper in Manhattan, I payed a crew of undocumented Polish workers to demolish the historic Bonwit Teller store, including art deco features. All this to make architectural critic Paul Goldberger say in 1983 that the tower's atrium is "the most pleasant interior public space to be completed in New York in some years". At the same time I also started a repair job on the Wollman Rink in Central Park and completed the work in three months for $1.95 million, which was $775,000 less than the initial budget!

<small>1978</small>  
Purchased a 50 percent stake in the derelict Commodore Hotel and turned it into the Grand Hyatt Hotel in 2 years of remodeling

<small>1971</small>  
Was promoted to president of the company and renamed it The Trump Organization

<small>1968</small>  
Began my career at my father's real estate development company, Elizabeth Trump & Son


#### PERSONAL LIFE

<small>2006</small>  
Melania gained United States citizenship and gave birth to our son, Barron

<small>2005</small>  
Married her

<small>1998</small>  
Met my future third wife, Melania Knauss

<small>1999</small>  
Divorced Marla ¯\_(ツ)_/¯

<small>1993</small>  
Married Marla and had a daughter, we named her Tiffany, because I like Tiffany & Company jewellery as well

<small>1992</small>  
Started affair with Marla Maples, so I had to divorce. God knows I love nice women, I love them all!

<small>1984</small>  
Birth of Eric Trump

<small>1982</small>  
Birth of Ivanka Trump

<small>1977</small>  
My first son is born. I called him Donald, of course!

<small>1977</small>  
Married Czech model Ivana Zelníčková


#### MEDIA CAREER

<small>2019</small>  
Was awarded Worst Actor and Worst Screen Combo at Golden Raspberry Awards for parts in "Death of a Nation" and "Fahrenheit 11/9"

<small>2015</small>  
Published a book "Crippled America: How to Make America Great Again"

<small>2011</small>  
Published a book "Time to Get Tough: Making America #1 Again" in coauthorship with Wynton Hall, Peter Schweizer and Meredith McIver

<small>2011</small>  
Published a book "Midas Touch: Why Some Entrepreneurs Get Rich – And Why Most Don't" in coauthorship with Robert Kiyosaki

<small>2011</small>  
Published a book "Trump Tower" in coauthorship with Jeffrey Robinson

<small>2009</small>  
Published a book "Think Like a Champion: An Informal Education in Business and Life" in coauthorship with Meredith McIver

<small>2008</small>  
Published a book "Never Give Up: How I Turned My Biggest Challenges into Success" in coauthorship with Meredith McIver

<small>2007</small>  
Published a book "Think Big and Kick Ass" in coauthorship with Bill Zanker

<small>2007</small>  
Received a star on the Hollywood Walk of Fame for being producer of Miss Universe pageant

<small>2006</small>  
Published a book "Why We Want You to Be Rich" in coauthorship with  Meredith McIver and Robert Kiyosaki

<small>2006</small>  
Published a book "How to Build a Fortune: Your Plan for Success From the World's Most Famous Businessman"

<small>2006</small>  
Published a book "The Best Real Estate Advice I Ever Received: 100 Top Experts Share Their Strategies"

<small>2006</small>  
Published a book "Trump 101: The Way to Success" in coauthorship with Meredith McIver

<small>2005</small>  
Published a book "The Best Golf Advice I Ever Received"

<small>2005</small>  
Performed a song with Megan Mullally at the 57th Primetime Emmy Awards

<small>2004 ― 2008</small>  
Ran short-form talk radio program "Trumped!" (one to two minutes on weekdays)

<small>2004</small>  
Published a book "Trump: How to Get Rich" in coauthorship with Meredith McIver

<small>2004</small>  
Published a book "The Way to the Top: The Best Business Advice I Ever Received"

<small>2004</small>  
Published a book "Think Like a Billionaire: Everything You Need to Know About Success, Real Estate, and Life" in coauthorship with Meredith McIver

<small>2003 ― 2015</small>  
Produced NBC reality shows "The Apprentice" and "The Celebrity Apprentice"

<small>2000</small>  
Published a book "Trump: The America We Deserve" in coauthorship with Dave Shiflett

<small>1997</small>  
Published a book "Trump: The Art of the Comeback" in coauthorship with Kate Bohner

<small>1991</small>  
Was awarded Worst Supporting Actor at Golden Raspberry Awards for a part in "Ghosts Can't Do It"

<small>1990</small>  
Published a book "Trump: Surviving at the Top" in coauthorship with Charles Leerhsen

<small>1987</small>  
Published a book "Trump: The Art of the Deal" in coauthorship with Tony Shwartz


#### EDUCATION

<small>2011</small>  
Asked friends who are prominent and wealthy alumni of the New York Military Academy to secure my academic records so they could not be seen by anyone, never!  

<small>1966</small>  
Transferred to the Wharton School of the University of Pennsylvania and graduated in May 1968 with a B.S. in economics  

<small>1964</small>  
Started studying in Fordham University  

<small>1959</small>  
Enrolled in the New York Military Academy, a private boarding school, after my parents discovered I made frequent trips into Manhattan without their permission  


#### LANGUAGES
🇺🇸 ENGLISH 🇷🇺 РУССКИЙ

#### SKILLS 

NEGOTIATING COUNTING REMODELING WRITING ACING SINGING REPORTING INCORPORATING SELLING ADVERTISING HOSTING COMPETING TWITTING PARENTING GAMBLING DATING SUING ORGANIZING FUNDING DEBATING ADVISING PRESBYTERIANING 

#### CHARACTER  

ADJUSTED CALM AMBITIOUS COMPETITIVE SOCIABLE DIRECT HOSTILE CARELESS IGNORANT INQUISITIVE BOLD CONFIDENT MISCHIEVOUS CHARMING INTERESTING DARING COLORFUL LAZY SELF-PROMOTING

#### LIKES 😃  

<a href="https://www.youtube.com/watch?v=u_aLESDql1U" rel="external">BILLIONS</a> FILET-O-FISH BIG MAC <a href="https://www.youtube.com/watch?v=RDrfE9I8_hs" rel="external">CHINA</a> QUARTER POUNDER DIET COKE TARIFFS BIBLE ARTOF DEAL PATRIOTS BEAUTIFUL MODELS GOLD REAL ESTATE WAR PROTESTERS CONSTRUCTION RUSSIANS BANKS SPORTS WOMEN MEXICO RED HAT KOREANS GOLF EVERYBODY <sup><a href="https://www.youtube.com/watch?v=0f9ysmciWUk" rel="external">[1]</a> <a href="https://www.youtube.com/watch?v=TTdmKaXAfAs">[2]</a></sup>

#### DISLIKES 😞  

DOGS MEDIA CNN GERMANS MEXICANS IMMIGRANTS SHITHOLE COUNTRIES UNATTRACTIVE WOMEN BLACKS SUSHI HOT-DOGS ALCOHOL FRUIT CHRISTMAS PARTIES LIBERALS 

#### WANTS 🥺
BE HEALTHY GROW A TREE BUILD TRUMP AIRPORT HAVE A TASTE DO A HARLEM SHAKE IN CONGRESS TO GOLF MORE OFTEN WIN ALL THE COURT SUITS
