**DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT DRAFT**

------
### Ryu Hoshi (リュウ Ryū)
* https://www.facebook.com/profile.php?id=100004808958030
* ryuwins@gmail.com
* https://twitter.com/denjinryu
* https://www.instagram.com/sworn_ryu/
------

### ― I do not compete with others, the only competition that challenges me is myself. As a fighter, friend and an employee I am known as contemplative, tortured and driven.
------

#### EXPERIENCE

<small>2018</small>
Amongst many fighters of the past was featured in the movie "Ready Player One". Ryu ready always!

<small>2017</small>  
United with unknown until then to me Power Rangers to defea resurrected M.Bison.Damn good fighters they are, even not knowing karate ways!

<small>2016</small>  
In "Street Fighter V" once and for all erased M.Bison from earth and tamed my inner Evil Ryu. Also spent some time on a side-project, mini-series "Street Fighter: Resurrection".

<small>2014</small>  
Filmed in a martial arts tutorial "Street Fighter: Assassin's Fist", revealing to audience forgotten art of Ansatsuken.

<small>2012</small>
The gods of intenet concluded me in the animated movie "Wreck-It Ralph", but rewarded me with a good drink for it!

<small>2008</small>  
My evil alter ego sneaked out of control and became a boss in "Street Fighter IV".

<small>2006</small>  
Borrowed my famous ripped gi to Soki in "Onimusha: Dawn of Dreams", gods informed me he needed that for the battle.

<small>1998</small>  
Defeated M. Bison in "Street Fighter Alpha 2", bastard wanted to use my heroic body for his evil intentions, but retreated with shame. Also this year I encountered Marvel universe in "Marvel vs. Capcom: Clash of Super Heroes" fighter,loyal to my employer, Capcom, of course.

<small>1997</small>  
Reunited with Ken, my friend and opponent in "Street Fighter III". Men's friendship works mysteriously. Also helped with Arika project "Street Fighter EX" 

<small>1996</small>  
Took care of villainous Akuma in "Street Fighter Alpha 2". As a freelance on "Super Puzzle Fighter II Turbo" tried myself in a new genre, puzzle games. Let the wrath of seven heavens come upon these malicious enigmas, never again!

<small>1995</small>  
Kept fighting in "Street Fighter Alpha: Warriors' Dreams".

<small>1994</small>
Screened in a movie "Street Fighter", so that the batllesof past would not be forgotten by millenial generation.

<small>1991</small>  
Was promoted to "Street Fighter II". Didn't stay there for long, celebrations and office dwelling is not for me!

<small>1987</small>  
Started working for Capcom project "Street Fighter". My partner was Ken Masters, the boss'name was Sagat.


#### PUBLICATIONS

<small>2011</small>
The true and humble story of me under pseudonim Tyler Wilde in an article "The evolution of Ken and Ryu"

<small>2003-2018</small>
For 15 years I have published comic books with Udon Entertainment depicting my adventures, bitter lessons and great victories.

------

#### ACHIEVEMENTS
* #1 in "Top 25 Street Fighter Characters" by IGN, who also called me "fancy", "icon" and "a testament to the virtue of simplicity" ❤️
* #2 in "Top 20 Street Fighter Characters of All Time" by GameDaily, same council found me worth of #6 place in "Top 25 Capcom Characters of All Time", which I proudly share with my partner Ken
* I was named "5th Most Powerful Street Fighter Character" by Screen Rant-san
* #71 in "Top 100 Heroes of All Time" by UGO Networks, also recognized #2 in their list of "Top 50 Street Fighter Characters"
* In a survey of 4000 online matches for Super Street Fighter IV, I got to be the most popular character, with 16.6% of players choosing my side
------

#### LIFE & EDUCATION
To live is to fight and to fight is to live.
I  started learning fighting at my master Gouken's castle, I was beaten at head way too often to remember when exactly.



#### LANGUAGES
🇺🇸 ENGLISH 🇨🇳 MANDARIN 🇯🇵 JAPANESE

#### SKILLS  

KARATE ENERGY ATTACK SHORYUKEN WALKING BAREFOOT PLAYING VIDEOGAMES DOING BURGERS MASHING POTATOES COPYWRITING ACTING VOICEOVERS

#### CHARACTER  

NOBLE DIRECT BOLD CONFIDENT DARING SCHIZOPHRENIC DRAMATIC PERSUASIVE IMMEDIATE WISE

#### LIFE LESSON
You must defeat Sheng Long to stand a chance.

#### LIKES 😃  

GI VEGETABLES BLOOD SMALL MARSHMELLOWS RED COLOR KILLED ENEMY

#### DISLIKES 😞  

BISONS GHOSTS SMARTPHONES SMELL OF SEAFOOD BARBER SHOPS SLEEVES

#### WANTS 🥺
BE FIT WRITE MORE BOOKS FIND A GIRLFRIEND TO GO TO CINEMA WITH KILL ALL OF AKUMA FAMILY
